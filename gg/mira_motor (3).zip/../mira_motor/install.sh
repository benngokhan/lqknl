#!/usr/bin/env bash
# BILGI DOZU motor — tek komut kurulum: bash install.sh
set -e
cd "$(dirname "$0")"
PY=${PYTHON:-python3}
command -v "$PY" >/dev/null 2>&1 || PY=python

echo "== BILGI DOZU motor kurulumu =="
echo "[1/4] Python paketleri..."
"$PY" -m pip install --quiet --upgrade pip
"$PY" -m pip install --quiet -r requirements.txt

echo "[2/4] ffmpeg garanti (imageio-ffmpeg binary)..."
"$PY" - <<'EOF'
import imageio_ffmpeg
open("ffmpeg_path.txt", "w").write(imageio_ffmpeg.get_ffmpeg_exe())
print("   ffmpeg:", imageio_ffmpeg.get_ffmpeg_exe())
EOF

echo "[3/4] QC kapısı selftest (sessiz-WAV bombası dahil)..."
"$PY" qc_check.py --selftest

echo "[4/4] Modül sözdizimi kontrolü..."
"$PY" -m py_compile mira_adapter.py shorts_pipeline.py publish.py channel_pulse.py qc_check.py

echo ""
echo "✅ KURULUM TAMAM — motor çalışır durumda."
echo "   Sonraki adımlar:"
echo "   1) cp .env.example .env  ->  değerleri gir (git'e ekleme!)"
echo "   2) YouTube yükleme için client_secrets.json'u shorts/ klasörüne koy"
echo "   3) Mira kodundan: from mira_adapter import ingest_draft, render_short"
