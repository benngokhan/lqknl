# MİRA × BİLGİ DOZU MOTOR — SAĞLAM PAKET

Amaç: Mira'nın ürettiği her video, kanaldaki şablonla PİKSEL PİKSEL aynı olsun.
Yol: Tasarımı LLM'e söyletmek yok — motor render eder, LLM sadece içerik üretir.

## PAKET İÇİ
```
shorts_pipeline.py        → RENDER MOTORU (şablon burada: plates/timing/music/render)
mira_adapter.py           → MİRA YAPIŞTIRMA KATMANI: ingest_draft() + render_short()
publish.py                → YouTube yükleme (OAuth, SEO metadata, --simulate)
qc_check.py               → QC KAPISI (saf ffmpeg; --selftest dahil)
channel_pulse.py          → SİNYAL DÖNGÜSÜ (kanal analizi → içerik direktifi)
MIRA_SYSTEM_PROMPT.txt    → LLM sistem promptu (içerik sözleşmesi)
mira_content_schema.json  → LLM çıktı şeması + örnek
MIRA_STYLE_SPEC.json      → tasarım sabitleri (referans)
ANA_PROMPT.md             → Arena agent'ıyla seri üretim brief'i
install.sh                → TEK KOMUT KURULUM
requirements.txt          → pip bağımlılıkları
.env.example              → gizli değişken şablonu (tokenlar KOD'A DEĞİL BURAYA)
.gitignore                → gizliler + ara dosyalar repoya girmesin
motor-ci.yml              → GitHub Action: her push'ta selftest (.github/workflows/ altına koy)
fonts/raw/                → Archivo Black + Inter + Anton (Türkçe glif testli)
```

## HIZLI KURULUM
```bash
bash install.sh          # pip + ffmpeg + QC selftest + sözdizimi — hepsi tek komut
cp .env.example .env     # değerleri gir
```

## MİRA AKIŞI (onay sonrası üretim)
```python
from mira_adapter import ingest_draft, render_short

# 1) LLM çıktısını dök:
r = ingest_draft(draft_json)              # script.txt + shorts_config.json yazar
# 2) Görselleri üret (Civitai vb.) -> shorts/<id>/bg1.png, bg2.png
# 3) TTS üret -> shorts/<id>/vo_raw.wav   (Edge TTS veya ElevenLabs)
# 4) Render + QC:
sonuc = render_short("s12_ornek")
if sonuc["ok"]:
    # 5) yayin (isteğe bağlı): python3 publish.py s12_ornek --privacy unlisted
    ...
else:
    log(sonuc["error"] or sonuc["qc"]["cikti"])   # QC kapısından geçmeyen kanala gitmez
```
CLI karşılığı:
```bash
python3 shorts_pipeline.py all <video_id>
python3 qc_check.py shorts/<video_id>/video.mp4 30 60
python3 publish.py <video_id> --simulate
```

## HAFTALIK SİNYAL DÖNGÜSÜ
```bash
python3 channel_pulse.py --handle @kankanal --key YOUTUBE_API_KEY
# -> content_directive.md içindeki JSON bloğunu Mira sistem promptuna ekle
```

## RAILWAY
- `motor-ci.yml` → repoda `.github/workflows/motor-ci.yml` olarak koy
- Railway Variables: GITHUB_TOKEN (fine-grained, sadece bu repo, Contents:R/W),
  LLM/TTS anahtarları (`.env.example` listesi)
- Dockerfile: README eski sürümdeki örnek geçerli (ffmpeg + pip + CMD)

## 3 CANLI BOMBA + PANZEHİRİ (hepsi pakette aktif)
1. Sessiz-WAV (int16 ölçeksiz) → qc_check LRA/LUFS kapısı yakalar
2. Türkçe glif bozulması (raqm) → fontlar Layout.BASIC ile çağrılıyor; DEĞİŞTİRME
3. 1.9GB RAM OOM → pipeline veryfast + threads 2 ayarlı; 512MB dyno'da render'ı ayrı worker'da koş
